package com.codeX;

public class Node <T>{

 Node next;
 T data;
}
