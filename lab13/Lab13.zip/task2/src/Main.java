import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// write your code here
        BinarySearchTree bst=new BinarySearchTree();
        Scanner sc=new Scanner(System.in);



        bst.insert(56);
        bst.insert(16);
        bst.insert(76);
        bst.insert(46);
        bst.insert(6);
        bst.insert(61);
        bst.insert(10);
        bst.insert(96);
        bst.insert(100);
        bst.insert(110);





int choice;
do {
    System.out.println("1.\tFind Height of Tree");
    System.out.println("2.\tCheck if Tree is Balanced");
    System.out.println("3.\tExit");
    choice = sc.nextInt();


    if(choice==1){
        System.out.println("The height of the Tree is: "+bst.getHeight(bst.root));
    System.out.println("");}
    if(choice==2){
        System.out.println(bst.isBalance(bst.root));
    System.out.println("");}
    if(choice==3){
        System.out.println("Program Ended");
        System.exit(0);
    }

}while(choice>=0 && choice<=3);

    }
}
