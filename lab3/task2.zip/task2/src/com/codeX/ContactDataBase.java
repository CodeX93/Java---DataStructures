package com.codeX;

import java.util.Arrays;
import java.util.Scanner;

public class ContactDataBase {
Scanner sc=new Scanner(System.in);

   public static MyArrayList<ContactDataBase> arr=new MyArrayList();


    private String FirstName;
    private String LastName;
    private String PhoneNumber;
    private String Email;


    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getPhoneNumber() {
        return PhoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        PhoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }





    public void AddDetails(){


ContactDataBase cdn =new ContactDataBase();
        System.out.println("Enter your First Name: ");
        String fn=sc.next();

        System.out.println("Enter your Last Name: ");
        String ln=sc.next();

        System.out.println("Enter your Email Address: ");
        String add=sc.next();

        System.out.println("Enter your Phone Number ");
        String PN=sc.next();

        cdn.setFirstName(fn);
        cdn.setLastName(ln);
        cdn.setEmail(add);
        cdn.setPhoneNumber(PN);

        arr.add(cdn);
        System.out.println("Contact Registered Successfully");




    }



    public void SearchContact(String PhoneNumber) {
        ContactDataBase cdn = new ContactDataBase();

        for (int i = 0; i < arr.size; i++) {

            if (arr.equals(PhoneNumber)) {

                System.out.println(Arrays.toString(ContactDataBase.arr.toArray()));
                break;

            }else System.out.println("Not Found");
        }

    }
        public void DeleteContact(String PhoneNumber){
            ContactDataBase cdn=new ContactDataBase();
            for(int i=0; i<arr.size;i++){


                if(arr.equals(PhoneNumber)){

                    arr.remove(i);
                    System.out.println("Contact Deleted Successfully.");
                    break;

                }else System.out.println("Not Found");
            }



    }










}
