public class Nodes {
        int value;

        Nodes(int value)  {
            this.value = value;
        }

    }
