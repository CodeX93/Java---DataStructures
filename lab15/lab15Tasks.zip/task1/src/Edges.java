public class Edges {

    int src, dest;

    public Edges(int src, int dest) {
        this.src = src;
        this.dest = dest;

    }

}
