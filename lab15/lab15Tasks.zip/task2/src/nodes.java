public class nodes<T> {

    T key;
    nodes next;

    // constructor to create a new linked list node
    public nodes(T key)
    {
        this.key = key;
        this.next = null;
    }
}
