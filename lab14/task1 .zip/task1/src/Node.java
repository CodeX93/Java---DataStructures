


public class Node  {
    int data;
            int height=0;
    Node left, right;

    public Node( int item)
    {
        this.data = item;
        this.left = this.right = null;
    }
}
